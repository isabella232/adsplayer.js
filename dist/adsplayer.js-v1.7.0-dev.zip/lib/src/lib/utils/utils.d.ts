export declare class Utils {
    static isAbsoluteURI: (uri: string) => boolean;
    static parseTime: (str: string) => number;
}

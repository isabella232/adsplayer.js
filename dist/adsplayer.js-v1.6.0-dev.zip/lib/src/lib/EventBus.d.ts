export declare enum AdEvents {
    TRIGGER_START = "triggerStart",
    TRIGGER_END = "triggerEnd",
    AD_START = "adStart",
    AD_END = "adEnd",
    CREATIVE_START = "creativeStart",
    CREATIVE_END = "creativeEnd",
    PLAY = "play",
    PAUSE = "pause",
    CLICK = "click"
}
export declare class EventBus {
    private registrations;
    private logger;
    constructor();
    addEventListener(type: string, listener: any): void;
    removeEventListener(type: string, listener: any): void;
    removeAllEventListener(): void;
    dispatchEvent(type: string, data?: object): void;
    private getListeners;
}
